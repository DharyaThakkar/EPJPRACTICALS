package JDBC;

import java.sql.*;




public class TestConnection {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Connection conn = null;
		
		try {
			//load the mysql jdbc driver into the memory for making connection
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			//connect to mysql database
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/testdb", "root", "Dharya@321");
			
			//confirmation
			System.out.println("Connected to MySql successfully");
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if(conn != null) {
					conn.close();
				}
			}catch(SQLException ex) {
				ex.printStackTrace();
			}
		}
	}
}
