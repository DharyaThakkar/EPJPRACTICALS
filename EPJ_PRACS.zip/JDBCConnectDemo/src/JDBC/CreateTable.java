package JDBC;
import java.sql.*;

public class CreateTable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Connection conn = null;
		Statement stmt = null;
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/testdb", "root", "Dharya@321");
			
			String sql = "CREATE TABLE students (" +
                    "id INT PRIMARY KEY AUTO_INCREMENT," +
                    "name VARCHAR(100)," +
                    "age INT," +
                    "course VARCHAR(50))";
			
			stmt = conn.createStatement();
			stmt.executeUpdate(sql);
			
			System.out.println("Table 'students' created successfully!");
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			try {
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
		}
	}
}
