package JDBC;
import java.sql.*;
public class InsertValues {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		try {
			
			Class.forName("com.mysql.cj.jdbc.Driver"); //load the JDBC Driver
			
			conn = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/testdb", "root", "Dharya@321"); //Establish the connection
			
			String sql = "INSERT INTO students (name, age, course) VALUES(?, ?, ?)";
			
			pstmt = conn.prepareStatement(sql); //We prepare the SQL command with placeholders that we will set using Java values.
			
			// Set parameter values(indexing starts from 1)
            pstmt.setString(1, "Amit");
            pstmt.setInt(2, 20);
            pstmt.setString(3, "Computer Science");
            
            
            int rowsInserted = pstmt.executeUpdate();
            
            if (rowsInserted > 0) {
                System.out.println("Record inserted successfully!");
            }
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			try {
				 if (pstmt != null) pstmt.close();
	                if (conn != null) conn.close();
	            } catch (SQLException ex) {
	                ex.printStackTrace();
	            }
			}
		}
   }
