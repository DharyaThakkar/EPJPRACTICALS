package com.spring.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.spring.pojo.Employee;

import jakarta.transaction.Transactional;

@Repository //it is an enhanced version of Component scan annotation and provides extra layer of security for database operation
public class EmployeeDao {
	SessionFactory factory;

	@Autowired
	public void setFactory(SessionFactory factory) {
		this.factory = factory;
	}
	
	public EmployeeDao() {
		
	}
	// insertion operation
	
	@Transactional //our spring will automatically handle database transaction, no need to handle manually
	public void Insert(int id, String name, String department) {
		Session session = factory.getCurrentSession();
		Employee record = new Employee(name, department);
		session.persist(record);
		System.out.println("data inserted successfully");
	}

	// Retrieval operation ( all data )
	
	@Transactional
	public List<Employee> find() {
		Session session = factory.getCurrentSession();
		List<Employee> data = session.createQuery("from Employee", Employee.class).list();
		return data;
	}

	// Retrieval operation ( get by id )
	
	@Transactional
	public Employee find(int id) {
		Session session = factory.getCurrentSession();
		Employee data = session.get(Employee.class, id);
		return data;
	}

	// update operation
	
	@Transactional
	public void update(Employee e) {
		Session session = factory.getCurrentSession();
		session.merge(e); // Correctly update the entity
		System.out.println("Record updated successfully");
	}

	// deletion operation
	@Transactional
	public void remove(int id) {
		Session session = factory.getCurrentSession();
		Employee e = session.get(Employee.class, id);
		if (e == null) {
			System.out.println("Record not found");
			return;
		}
		session.remove(e);
		System.out.println("record deleted successfully");
	}
}
