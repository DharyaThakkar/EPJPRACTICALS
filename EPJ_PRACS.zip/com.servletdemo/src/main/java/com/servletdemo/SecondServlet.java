package com.servletdemo;

import java.io.IOException;

import jakarta.servlet.Servlet;
import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.ServletContext;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/second")
public class SecondServlet extends HttpServlet{
	ServletConfig con;
	ServletContext context;
	
	private boolean validate(String email, String password) {
		if("dharya@gmail.com".equals(email) && "dharya@123".equals(password)) {
			return true;
		}
		return false;
	}

	private void count(HttpSession session) {
		int visitCount = (int) session.getAttribute("visitCount");
		
		if(visitCount == 0) {
			visitCount = 1;
		}
		else {
			visitCount++;
		}
		
		session.setAttribute("visitCount", visitCount);
	}
	
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		resp.setContentType("text/html");
		this.con = getServletConfig();
		this.context = this.con.getServletContext();
		
		
		
		String name = req.getParameter("name");
		String email = req.getParameter("email");
		String password = req.getParameter("password");
		
		boolean result = validate(email, password);
		
		Cookie nameCookie = new Cookie("data",name);
		nameCookie.setMaxAge(60); //pass value in terms of seconds
		
		resp.addCookie(nameCookie);
		
		
		//every request has a unique session id
		HttpSession session = req.getSession(); //get session id details from the Http req object.
		boolean newSession = session.isNew();
		
		if(newSession == true) {
			session.setAttribute("visitCount", 0);
		}
		count(session);
		
		String msg = (String) this.context.getAttribute("msg");
		
		resp.getWriter().println("<html><body><h2>" + msg + "</h2>");
		if(result == true) {
			resp.getWriter().println("details are correct");
		}
		else {
			resp.getWriter().println("email and password is invalid");
		}
		resp.getWriter().println("<p> this visit count is : " + session.getAttribute("visitCount") + "</p></body></html>");
		
		
		
		
		//session.setAttribute("name", name);
		
		
		
//		System.out.println("second servlet service method is called");
//		String name = (String) this.context.getAttribute("name");
//		
//		Cookie userCookie = new Cookie("username", "CodeTantra"); //cookie is stored in client-side i.e., client browser
//		userCookie.setMaxAge(60 * 60); //valid for 1 hour
//		resp.addCookie(userCookie);
//		
//		String resDetails = "The servlet file is created by ";
//		resp.getWriter().println(resDetails + name);
		
	}
	
	

	
		
}

// session details are stored at server-side
//if we don't modify the session details, then it will not be stored in server storage.
