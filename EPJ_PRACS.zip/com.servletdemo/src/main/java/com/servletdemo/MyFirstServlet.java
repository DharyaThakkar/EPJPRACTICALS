package com.servletdemo;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.Servlet;
import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.ServletContext;
//import jakarta.servlet.annotation.WebServlet;

//@WebServlet("/hello")
public class MyFirstServlet implements Servlet {
	
	ServletConfig con;
	ServletContext context;
	@Override
	public void init(ServletConfig config) throws ServletException { // will be called after the creation of the object.
		// TODO Auto-generated method stub
		System.out.println("myservlet object is created");
		this.con = config;
		this.context = config.getServletContext();
		
	}

	@Override
	public ServletConfig getServletConfig() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//Business logic goes here
		System.out.println("The service method is called");
		
		System.out.println(req.getRequestId());
		
		this.context.setAttribute("msg","This is the message from myservlet class file");
		
		String name = this.con.getInitParameter("name");
		//this.context.setAttribute("name", name);
	    PrintWriter obj = res.getWriter();
	    //obj.println("<html><body><h2> Hello World </h2></body></html>");
	    obj.println("<html><body><h2> Hello, " + name + "</h2>");
	    
	    String form = "<form action='/com.servletdemo/second' method='get'>" + 
				  "Name : <input type='text' name='name' /> <br/>" +
				  "Email : <input type='email' name='email'/><br/>" +
				  "password : <input type'password' name='password' />" +
				  "<input type='submit' />" +
				  "</form></body></html>";
	
	res.getWriter().println(form);
	    
		
		
	}

	@Override
	public String getServletInfo() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void destroy() { //will be called before the destruction of the object.
		// TODO Auto-generated method stub
		System.out.println("The object is ready to destroy");
		
	}
	
	

}
