package com.servletdemo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class StudentDAO {
	String url = "jdbc:mysql://localhost:3306/parul";
	String username = "root";
	String password = "Dharya@321";
	Connection con;
	PreparedStatement ptmt;

	public StudentDAO() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection(url, username, password);
			System.out.println("Database connected successfully");
		} catch (Exception e) {
			e.printStackTrace();
		}	
	}

	public void create(int id, String name, int age) throws SQLException {
		String sql = "Insert into students(id,name,age) values(?,?,?)";
		ptmt = con.prepareStatement(sql);
		ptmt.setInt(1, id);	
		ptmt.setString(2, name);
		ptmt.setInt(3, age);

		int rowEffects = ptmt.executeUpdate();

		if (rowEffects > 0) {
			System.out.println("data inserted successfully");
		}
	}
	
	public void get() throws SQLException {
		String sql = "select * from students";
		ptmt = con.prepareStatement(sql);
		ResultSet result = ptmt.executeQuery();
	}

}
