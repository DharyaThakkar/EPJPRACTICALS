package com.hibernate;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.pojo.Employee;

public class Main {
     public static void main(String[] args) {
		SessionFactory factory = new Configuration().configure().buildSessionFactory();
		Session session = factory.openSession();
		
		try {
			Transaction tx = session.beginTransaction();
			Employee record = new Employee(1,"Dharya", "CSE");
			session.persist(record);
			
			tx.commit();
			session.close();
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
}

//if the entity object is not managed by entity manager, it will in the transist state and if it is managed by
//entity manager , then it will be in the managed state.
