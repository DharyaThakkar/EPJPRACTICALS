package com.spring;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("com.spring")
public class Main {
	
	//@Autowired //field injection
	private static Animal obj;
	
	//setter injection
	@Autowired
	public void setObj(Animal obj) {
		Main.obj = obj;
	}
	
	public static void main(String[] args) {
		
		ApplicationContext  Container = new AnnotationConfigApplicationContext(Main.class);
        // loose coupling
        //Animal obj = null;

        // object creating at runtime
        //obj = (Animal) Container.getBean(Cat.class);



        // loose coupling method calling
        if (obj != null) {
            obj.details();
        }
    }
}
