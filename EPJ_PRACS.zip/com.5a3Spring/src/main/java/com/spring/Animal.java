package com.spring;

public interface Animal {
	
	public void sound();

	public void details();

}
